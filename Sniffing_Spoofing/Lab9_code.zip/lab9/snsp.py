from scapy.all import *
def spoof(pkt):
	a=IP(dst=pkt[IP].src,src=pkt[IP].dst)
	b=ICMP(type='echo-reply',code=0,seq=pkt[ICMP].seq,id=pkt[ICMP].id)

	print('get icmp from '+a.dst+',spoof as '+a.src)
	pkt.show()
	p=a/b/pkt[Raw]
	send(p)

sniff(iface='br-a2ed327d9f61',filter='icmp[icmptype]==icmp-echo',prn=spoof)
