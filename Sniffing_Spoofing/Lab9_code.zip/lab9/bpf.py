#!/usr/bin/env python3
from scapy.all import *
import sys

def print_pkt(pkt):
    pkt.show()

filters=['icmp','tcp and src net 10.0.2.15 and dst port 23','net 10.134.160.0/21']
print('''choices for packet filtering
	0.Capture only the ICMP packet
	1.Capture any TCP packet that comes from 10.0.2.15 and with a destination port number 23.
	2.Capture packets comes from or to go to subnet 10.134.160.0/21.''')
ch=int(input('please input num(0,1,2)'))
print('filter:'+filters[ch])
pkt=sniff(iface='enp0s3',filter=filters[ch],prn=print_pkt)
