from scapy.all import *
global ttl
ttl=0
def count_ttl(pkt):
	global ttl
	ttl=ttl+1
	if(pkt[ICMP].type==0 and pkt[IP].src=='10.134.160.148'):
		print('get reply from target host while ttl='+str(ttl))
		exit(0)

print('sniff...icmp reply')
sniff(iface='enp0s3',filter='icmp',prn=count_ttl)
