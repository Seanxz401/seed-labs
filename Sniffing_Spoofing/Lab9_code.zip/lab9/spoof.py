from scapy.all import *
a=IP()
srcip=input('please input fake srcIP:')
a.src=srcip
b=ICMP()
p=a/b
send(p)
