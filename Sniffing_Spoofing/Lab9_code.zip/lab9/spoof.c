#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<netinet/in.h>
#include<time.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/timerfd.h>
#include <unistd.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netdb.h>
#include <errno.h>
#include <malloc.h>
#include <stdint.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <asm/byteorder.h>

#define BYTE u_char
#define DWORD u_long
#define USHORT u_short

//IP报头
typedef struct IP_HEADER {
#if defined(__LITTLE_ENDIAN_BITFIELD)
	__u8	ihl:4,			//4位头部长度 一位4个字节，，最多15*4个字节(可选项)
		version:4;		//4位版本号
#elif defined (__BIG_ENDIAN_BITFIELD)
	__u8	version:4,
  		ihl:4;
#else
#error	"Please fix <asm/byteorder.h>"
#endif
	__u8	tos;			//8位服务类型
	__be16	tot_len;		//16位总长度
	__be16	id;			//16位标识符
	__be16	frag_off;		//3位标志加13位片偏移
	__u8	ttl;			//8位生存时间
	__u8	protocol;		//8位上层协议号
	__sum16	check;		//16位校验和
	__be32	saddr;			//32位源IP地址
	__be32	daddr;			//32位目的IP地址
	/*The options start here. */
} IP_HEADER;

//ICMP报头
typedef struct ICMP_HEADER
{
    u_char type;    //8位类型字段
    u_char code;    //8位代码字段
    u_short cksum; //16位校验和
    u_short id;    //16位标识符
    u_short seq;   //16位序列号
} ICMP_HEADER;

//计算网际校验和函数
u_short checksum(u_short* pBuf, int iSize)
{
    unsigned long cksum = 0;
    while (iSize > 1)
    {
        cksum += *pBuf++;
        iSize -= sizeof(u_short);
    }
    if (iSize)//如果 iSize 为正，即为奇数个字节
    {
        cksum += *(u_char*)pBuf; //则在末尾补上一个字节，使之有偶数个字节
    }
    cksum = (cksum >> 16) + (cksum & 0xffff);
    cksum += (cksum >> 16);
    return (u_short)(~cksum);
}

void sendSpoof()
{
    	int sd;
	struct sockaddr_in sin;
	char buffer[1024];
	const BYTE ICMP_ECHO_REQUEST = 8;    //请求回显
	const BYTE ICMP_ECHO_REPLY = 0;    //回显应答
	const BYTE ICMP_TIMEOUT = 11;   //传输超时

	//其他常量定义
	const int DEF_ICMP_DATA_SIZE = 32;    //ICMP报文默认数据字段长度
	const int MAX_ICMP_PACKET_SIZE = 1024;  //ICMP报文最大长度（包括报头）
	const DWORD DEF_ICMP_TIMEOUT = 3000;  //回显应答超时时间
	const int DEF_MAX_HOP = 30;    //最大跳站数
	
	//填充ICMP报文中每次发送时不变的字段
	char * IcmpSendBuf = buffer+sizeof(IP_HEADER);//发送缓冲区
	memset(IcmpSendBuf, 0, sizeof(IcmpSendBuf)); 
	
	/*填写ICMP头，回显请求*/
	ICMP_HEADER* pIcmpHeader = (ICMP_HEADER*)IcmpSendBuf;
	pIcmpHeader->type = ICMP_ECHO_REQUEST; 
	pIcmpHeader->code = 0; 
	/*ID字段为当前进程号*/
	//pIcmpHeader->id = (USHORT)GetCurrentProcessId();
	pIcmpHeader->id = 0x002a;
	memset(IcmpSendBuf + sizeof(ICMP_HEADER), 'E', DEF_ICMP_DATA_SIZE);//数据字段
	
	//填充ICMP报文中每次发送变化的字段
        ((ICMP_HEADER*)IcmpSendBuf)->cksum = 0;                   //校验和先置为0
        //((ICMP_HEADER*)IcmpSendBuf)->seq = htons(usSeqNo++);      //填充序列号
        ((ICMP_HEADER*)IcmpSendBuf)->seq = 256;
        ((ICMP_HEADER*)IcmpSendBuf)->cksum = checksum((USHORT*)IcmpSendBuf, sizeof(ICMP_HEADER) + DEF_ICMP_DATA_SIZE); //计算校验和
	//printf("%d$$$$$$$$$$\n",sizeof(char));
	IP_HEADER* pIPHeader = (IP_HEADER*)buffer;
	
	pIPHeader->version	= 4;
	pIPHeader->ihl		= 5;
	pIPHeader->tos		= 0;
	pIPHeader->tot_len	= (sizeof(IP_HEADER) + sizeof(ICMP_HEADER) + DEF_ICMP_DATA_SIZE);
	pIPHeader->id		= 1;
	pIPHeader->frag_off	= 0x000;
	pIPHeader->ttl		= 100;
	pIPHeader->protocol	= 1;	//TCP的协议号为6，UDP的协议号为17。ICMP的协议号为1，IGMP的协议号为2
	pIPHeader->saddr	= inet_addr("10.9.0.99");
	pIPHeader->daddr	= inet_addr("10.0.2.15");
	//memcpy(&pIPHeader->saddr,packet+30,4);
	//memcpy(&pIPHeader->daddr,packet+26,4);
	
	pIPHeader->check	= checksum((USHORT*)buffer, sizeof(IP_HEADER)+sizeof(ICMP_HEADER)+DEF_ICMP_DATA_SIZE);
	
	sd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
	if(sd < 0) {
		perror("socket() error"); exit(-1);
	}
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr=inet_addr("10.0.2.15");
	int ip_len = (sizeof(IP_HEADER) + sizeof(ICMP_HEADER) + DEF_ICMP_DATA_SIZE);
	if(sendto(sd, buffer, ip_len, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0) {
		perror("sendto() error"); exit(-1);
	}
	else {
		printf("SEND OUT!!!%d\n",pIPHeader->tot_len);
	}

}
int main(){
	sendSpoof();
}


