from scapy.all import *

a=IP()
a.dst='10.134.160.148'
b=ICMP()
for i in range(1,65):
	a.ttl=i
	send(a/b)
