int main()
{
    system("ls");
    return 0;
}