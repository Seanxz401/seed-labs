int main()
{
    printf("you are in fake ls!\n");
    return 0;
}