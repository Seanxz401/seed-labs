#include <stdio.h>
#include <string.h>
int main(){
	FILE * f_req=fopen("ip_req.bin","rb");
	unsigned char ip_req[10000];
	int n=fread(ip_req,1,10000,f_req);

	unsigned char name[5]="seana";
	memcpy(ip_req+41,name,4);
	unsigned char * p=ip_req+41;
	for(int i=0;i<5;i++){
		printf("%c\n",*p);
		p++;
	}
	return 0;
}
